# JobNest
A React-based job and event listing portal built with reusable components, clean UI, and subtle animations. Designed to demonstrate React fundamentals and real-world frontend development skills.
